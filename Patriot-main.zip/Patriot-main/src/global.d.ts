interface Navigator {
  app?: {
    exitApp?: () => void;
  };
}
